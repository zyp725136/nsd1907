#include <linux/cpumask.h>

void foo(void)
{
	int x = nr_cpu_ids;
}
