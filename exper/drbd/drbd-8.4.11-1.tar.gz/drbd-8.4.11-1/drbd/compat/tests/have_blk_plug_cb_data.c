#include <linux/blkdev.h>

struct blk_plug_cb cb = { .data = NULL, };
