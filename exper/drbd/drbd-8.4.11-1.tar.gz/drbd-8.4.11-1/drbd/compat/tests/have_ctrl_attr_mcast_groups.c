#include <linux/genetlink.h>

void f(void)
{
	int i = CTRL_ATTR_MCAST_GROUPS;
}
