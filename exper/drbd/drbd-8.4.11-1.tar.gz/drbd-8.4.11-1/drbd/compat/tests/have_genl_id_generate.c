#include <linux/genetlink.h>

void test(void)
{
	int i = GENL_ID_GENERATE;
}
