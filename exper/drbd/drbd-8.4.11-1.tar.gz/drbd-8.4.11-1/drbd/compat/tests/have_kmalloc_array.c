#include <linux/slab.h>

void test(void)
{
	kmalloc_array(0, 0, 0);
}
