/* FAKE include file for poor old kernels lacking <crypto/hash.h> */
